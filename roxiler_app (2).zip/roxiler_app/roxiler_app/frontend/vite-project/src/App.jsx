import React, { useState, useEffect } from 'react';
import Statistics from './components/Statistics'; // Import the Statistics component
import BarChart from './components/BarChart';
import PieChart from './components/PieChart';
import TransactionsTable from './components/TransactionsTable';

// Styles for the App component
const styles = {
  body: {
    background: 'black', // Navy blue to light blue gradient
    margin: 0,
    padding: 0,
    minHeight: '100vh',
    fontFamily: 'Arial, sans-serif',
  },
  appContainer: {
    fontFamily: 'Arial, sans-serif',
    textAlign: 'center',
    maxWidth: '100%',
    color: 'white', // White text for contrast
  },
  header: {
    backgroundColor: '#2c3e50', 
    color: 'white', 
    padding: '20px 20px', 
    fontSize: '1.5rem', 
    textAlign: 'center', 
    textTransform: 'uppercase', 
    letterSpacing: '1.5px', 
    fontWeight: 'bold', 
    borderBottom: '5px solid #1abc9c', 
    borderRadius: '0 0 0px 20px', 
    backgroundImage: 'linear-gradient(135deg, #2c3e50, #34495e, #1abc9c)', 
    boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)', 
  },
  mainContent: {
    padding: '40px',
    maxWidth: '2100px',
    margin: '0 auto',
  },
  componentSection: {
    marginBottom: '50px', 
  },
  footer: {
    backgroundColor: '#2c3e50', 
    color: 'white', 
    padding: '20px 10px', 
    fontSize: '1.5rem', 
    textAlign: 'center',
    borderTop: '5px solid #1abc9c', 
    borderRadius: '20px 20px 0 0', 
    backgroundImage: 'linear-gradient(135deg, #2c3e50, #34495e, #1abc9c)', 
    boxShadow: '0 -4px 15px rgba(0, 0, 0, 0.2)', 
    marginTop: '60px', 
  },
};

const App = () => {
  const [month, setMonth] = useState('November');

  // Apply gradient background to the entire body using useEffect
  useEffect(() => {
    document.body.style.background = styles.body.background;
    document.body.style.margin = styles.body.margin;
    document.body.style.padding = styles.body.padding;
    document.body.style.minHeight = styles.body.minHeight;
    document.body.style.fontFamily = styles.body.fontFamily;
  }, []);

  return (
    <div style={styles.appContainer}>
      <header style={styles.header}>
        <h1>Monthly Transaction Statistics</h1>
      </header>

      <main style={styles.mainContent}>

        {/* Transactions Table */}
        <div style={styles.componentSection}>
          <TransactionsTable />
        </div>

        {/* Render the Statistics Component */}
        <div style={styles.componentSection}>
          <Statistics />
        </div>

        {/* Bar Chart */}
        <div style={styles.componentSection}>
          <BarChart />
        </div>

        {/* Pie Chart */}
        <div style={styles.componentSection}>
          <PieChart />
        </div>

        
      </main>

      <footer style={styles.footer}>
        <p>© Sonali Kadam </p>
      </footer>
    </div>
  );
};

export default App;
